
<?php $__env->startSection('title','Comments'); ?>
<?php $__env->startSection('body'); ?>




<?php $__currentLoopData = $postArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card-body rounded my-2" style="position: relative">
    <div class="card-title row">
        <div class="col-md-1">
            <a class="text-decoration-none text-dark" href="<?php echo e(url('/comments/'.$item->post_id)); ?>">
                <img class="icon" src="<?php echo e(isset($item->icon) ? url($item->icon) : url('image/img.jpg')); ?>" alt="icon"
                    id="preview_icon" style="width: 70px;height: 70px;border-radius: 50%;">
        </div>
        <div class="col-md-10 mt-2">
            <h3><?php echo e($item->post_title); ?></h3>
            <footer class="blockquote-footer"><?php echo e($item->user_name); ?>&nbsp;|&nbsp;<i class="fa fa-calendar"></i>
                <?php echo e($item->date); ?>

            </footer>
            </a>
        </div>
    </div>
    <div class="card-body" style="background-color: #f7f7f7;">
        <?php echo e($item->post_details); ?>

        <div class="float-right">
            
        </div>
    </div>
</div>


<div class="card-body rounded">
    <form method="POST" action="<?php echo e(url('/commentadd')); ?>" class="needs-validation" novalidate>
        <div class="card-title row mb-0">
            <?php echo csrf_field(); ?>
            <div class="col-md mt-1">
                <input type="hidden" name="post_id" value="<?php echo e($item->post_id); ?>">
                <input type="hidden" name="user_id" value="<?php echo e($item->user_id); ?>">
                <input type="hidden" name="comment_id" value="<?php echo e(isset($cmtArr['id']) ? $cmtArr['id'] : null); ?>">
                <?php if(isset($cmtArr)): ?>
                <input class="form-control" placeholder="User Name" type="text" name="u_name"
                    value="<?php echo e(isset($cmtArr['user_name']) ? $cmtArr['user_name'] : null); ?>" readonly required>
                <?php else: ?>
                <input class="form-control" placeholder="User Name" type="text" name="u_name" required>
                <?php endif; ?>
            </div>
        </div>
        <div class="row mt-1">
            <div class="col-md mt-1">
                <textarea class="form-control" name="message" placeholder="Comment"
                    required><?php echo e(isset($cmtArr['comment']) ? $cmtArr['comment'] : old('comment')); ?></textarea>
                <button class="mt-2 btn btn-secondary text-white px-5 nbtn" type="submit">Post</button>
            </div>
        </div>
    </form>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php if(isset($comments)): ?>
<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card-body my-2 rounded">
    <div class="card-title row">
        <div class="col-md">
            <div class="dropdown dropleft float-right">
                <button type="button" class="btn" data-toggle="dropdown">
                    <i class="fa fa-ellipsis-v"></i>
                </button>
                <div class="dropdown-menu">
                    <a class="dropdown-item text-dark" href="<?php echo e(url('/comedit/'.$data->id)); ?>"><i
                            class="fa fa-pencil-square-o text-secondary"></i>&nbsp;Edit</a>
                    <a class="dropdown-item text-dark modalopen" data-id="<?php echo e($data->id); ?>" href="#modalForm"
                        data-toggle="modal"><i class="fa fa-trash-o text-danger"></i>&nbsp;&nbsp;Delete</a>
                </div>
            </div>
            <div class="mt-2">
                <?php echo e($data->comment); ?>

                <div class="float-right mr-2">
                    <footer class="blockquote-footer"><?php echo e($data->user_name); ?>

                    </footer>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<div class="modal fade" id="modalForm">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="post" action="<?php echo e(url('/comentsdelete')); ?>">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Comment Delete</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <input type="hidden" name="id" class="id">
                <div class="modal-body">Select "Delete" below if you are ready to want to delete this Comment <span
                        class="text-capitalize font-weight-bold" id="name"></span>.</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"
                        onclick="reset();">Close</button>
                    <button type="submit" class="btn btn-danger">
                        <?php echo e(__('Delete')); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    $('.modalopen').click(function() {
         $('.id').attr('value',$(this).data('id'));
    });
    // Disable form submissions if there are invalid fields
(function() {
  'use strict';
  window.addEventListener('load', function() {
    // Get the forms we want to add validation styles to
    var forms = document.getElementsByClassName('needs-validation');
    // Loop over them and prevent submission
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/testing3/resources/views/comments.blade.php ENDPATH**/ ?>