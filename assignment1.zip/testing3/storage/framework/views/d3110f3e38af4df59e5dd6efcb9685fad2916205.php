<?php $__env->startSection('title','Most Recent Posts'); ?>
<?php $__env->startSection('body'); ?>
<?php if(isset($values)): ?>
<?php $__currentLoopData = $values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card-body rounded my-2" style="position: relative">
    <div class="card-title row">
        <div class="col-md-1">
            <a class="text-decoration-none text-dark" href="<?php echo e(url('/comments/'.$item->post_id)); ?>">
                <img class="icon" src="<?php echo e(isset($item->icon) ? url($item->icon) : url('image/img.jpg')); ?>" alt="icon"
                    id="preview_icon">
        </div>
        <div class="col-md-10 mt-2">
            <h3><?php echo e($item->post_title); ?></h3>
            <footer class="blockquote-footer"><?php echo e($item->user_name); ?>|&nbsp;<i class="fa fa-calendar"></i>
                <?php echo e($item->date); ?>

            </footer>
            </a>
        </div>
        <div style="position:absolute;z-index:1;right:10px; ">
            <div class="dropdown dropleft ">
                <button type="button" class="btn" data-toggle="dropdown">
                    <i class="fa fa-ellipsis-v"></i>
                </button>
                <div class="dropdown-menu">
                    <a class="dropdown-item text-dark" href="<?php echo e(url('home/'.$item->post_id)); ?>"><i
                            class="fa fa-pencil-square-o text-secondary"></i>&nbsp;Edit</a>
                    <a class="dropdown-item text-dark modalopen" data-id="<?php echo e($item->post_id); ?>" href="#modalForm"
                        data-toggle="modal"><i class="fa fa-trash-o text-danger"></i>&nbsp;&nbsp;Delete</a>
                </div>
            </div>
        </div>
    </div>
    <a class="text-decoration-none text-dark" href="<?php echo e(url('/comments/'.$item->post_id)); ?>">
        <div class="card-body" style="background-color: #f7f7f7;">
            <?php echo e($item->post_details); ?>

            <div class="float-right">
                <?php $__currentLoopData = $total; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->post_id ==$data->post_id ): ?>
                <footer class="blockquote-footer" style="font-size: 1.5rem">
                    <?php echo e($data->total); ?>&nbsp;<i class="fa fa-comments-o"></i>
                </footer>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </a>
</div>
<div class="modal fade" id="modalForm">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="post" action="<?php echo e(url('/postdelete')); ?>">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Post Delete</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <input type="hidden" name="id" class="id">
                <div class="modal-body">Select "Delete" below if you are ready to want to delete this Post <span
                        class="text-capitalize font-weight-bold" id="name"></span>.</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"
                        onclick="reset();">Close</button>
                    <button type="submit" class="btn btn-danger">
                        <?php echo e(__('Delete')); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<h1>No details found...</h1>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\demo\Newfolder\resources\views/recentpost.blade.php ENDPATH**/ ?>