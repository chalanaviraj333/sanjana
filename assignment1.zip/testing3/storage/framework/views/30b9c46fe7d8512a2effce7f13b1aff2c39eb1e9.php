
<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('body'); ?>

<div class="card-body rounded my-2" style="background-color: #f7f7f7">
   <form method="POST" action="<?php echo e(url('/post')); ?>" class="needs-validation" novalidate enctype="multipart/form-data">
      <div class="card-title row mb-0">
         <div class="col-md-1 mb-0">
            <?php echo csrf_field(); ?>
            <img class="mt-1" src="<?php echo e(isset($postArr['icon']) ? url($postArr['icon']) : url('image/img.jpg')); ?>"
               alt="icon" id="preview_icon" onclick="event.preventDefault();document.getElementById('icon').click();"
               style="width: 70px;height: 70px;border-radius: 50%;">
            <input class="form-control" type="file" name="icon" accept="image/*" id="icon" style="display: none;">
         </div>
         <div class="col-md mt-1">
            <input class="form-control" placeholder="Title" type="text" name="title"
               value="<?php echo e(isset($postArr['post_title']) ? $postArr['post_title'] : old('title')); ?>" required>

            <input type="hidden" name="id" value="<?php echo e(isset($postArr['post_id']) ? $postArr['post_id'] : old('id')); ?>">
         </div>
         <div class="col-md mt-1">
            <?php if(isset($postArr)): ?>
            <input class="form-control" placeholder="User Name" type="text" name="u_name"
               value="<?php echo e($postArr['user_name']); ?>" readonly required>
            <?php else: ?>
            <input class="form-control" placeholder="User Name" type="text" name="u_name"
               value="<?php echo e(isset($postArr['user_name']) ? $postArr['user_name'] : old('u_name')); ?>" required>
            <?php endif; ?>
         </div>
      </div>
      <div class="row mt-0">
         <div class="col-md-1"></div>
         <div class="col-md-11 mt-1">
            <div>
               <textarea class="form-control" name="message" placeholder="Message"
                  required><?php echo e(isset($postArr['post_details']) ? $postArr['post_details'] : old('message')); ?></textarea>
            </div>
            <br>
            <div class="row">
               <div class="col-md-4 mt-1">
                  <button class="btn btn-secondary text-white px-5 nbtn" type="submit">Post</button>
               </div>
            </div>
         </div>
      </div>
   </form>
</div>
<?php if(isset($values)): ?>
<?php $__currentLoopData = $values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card-body rounded my-2" style="position: relative">
   <div class="card-title row">
      <div class="col-md-1">
         <a class="text-decoration-none text-dark" href="<?php echo e(url('/comments/'.$item->post_id)); ?>">
            <img class="icon" src="<?php echo e(isset($item->icon) ? url($item->icon) : url('image/img.jpg')); ?>" alt="icon"
               id="preview_icon">
      </div>
      <div class="col-md-10 mt-2">
         <h3><?php echo e($item->post_title); ?></h3>
         <footer class="blockquote-footer"><?php echo e($item->user_name); ?>|&nbsp;<i class="fa fa-calendar"></i> <?php echo e($item->date); ?>

         </footer>
         </a>
      </div>
      <div style="position:absolute;z-index:1;right:10px; ">
         <div class="dropdown dropleft ">
            <button type="button" class="btn" data-toggle="dropdown">
               <i class="fa fa-ellipsis-v"></i>
            </button>
            <div class="dropdown-menu">
               <a class="dropdown-item text-dark" href="<?php echo e(url('home/'.$item->post_id)); ?>"><i
                     class="fa fa-pencil-square-o text-secondary"></i>&nbsp;Edit</a>
               <a class="dropdown-item text-dark modalopen" data-id="<?php echo e($item->post_id); ?>" href="#modalForm"
                  data-toggle="modal"><i class="fa fa-trash-o text-danger"></i>&nbsp;&nbsp;Delete</a>
            </div>
         </div>
      </div>
   </div>
   <a class="text-decoration-none text-dark" href="<?php echo e(url('/comments/'.$item->post_id)); ?>">
      <div class="card-body" style="background-color: #f7f7f7;">
         <?php echo e($item->post_details); ?>

         <div class="float-right">
            <?php $__currentLoopData = $total; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($item->post_id ==$data->post_id ): ?>
            <footer class="blockquote-footer" style="font-size: 1.5rem">
               <?php echo e($data->total); ?>&nbsp;<i class="fa fa-comments-o"></i>
            </footer>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </footer>
         </div>
      </div>
   </a>
</div>
<div class="modal fade" id="modalForm">
   <div class="modal-dialog modal-lg">
      <div class="modal-content">
         <form method="post" action="<?php echo e(url('/postdelete')); ?>">
            <?php echo csrf_field(); ?>
            <div class="modal-header">
               <h5 class="modal-title">Post Delete</h5>
               <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
               </button>
            </div>
            <input type="hidden" name="id" class="id">
            <div class="modal-body">Select "Delete" below if you are ready to want to delete this Post <span
                  class="text-capitalize font-weight-bold" id="name"></span>.</div>
            <div class="modal-footer">
               <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="reset();">Close</button>
               <button type="submit" class="btn btn-danger">
                  <?php echo e(__('Delete')); ?>

               </button>
            </div>
         </form>
      </div>
   </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<script src="https://code.jquery.com/jquery-3.1.1.slim.min.js"></script>
<script type="text/javascript">
   $('.modalopen').click(function() {
    
         $('.id').attr('value',$(this).data('id'));
    
    });
   // Disable form submissions if there are invalid fields
         (function() {
            'use strict';
            window.addEventListener('load', function() {
               // Get the forms we want to add validation styles to
               var forms = document.getElementsByClassName('needs-validation');
               // Loop over them and prevent submission
               var validation = Array.prototype.filter.call(forms, function(form) {
                  form.addEventListener('submit', function(event) {
                     if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                     }
                     form.classList.add('was-validated');
                  }, false);
               });
            }, false);
         })();
         
         function readURL(input) {
            if (input.files && input.files[0]) {
               var reader = new FileReader();
               reader.onload = function(e) {
                  $('#preview_icon').attr('src', e.target.result);
               }
               reader.readAsDataURL(input.files[0]);
            }
         }
         $("#icon").change(function() {
            readURL(this);
         });

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/testing3/resources/views/home.blade.php ENDPATH**/ ?>