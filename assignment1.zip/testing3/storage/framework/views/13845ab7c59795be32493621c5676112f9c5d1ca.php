<?php $__env->startSection('title','Documentation'); ?>
<?php $__env->startSection('body'); ?>

<br>
<br>
<br>
<h1>ER Diagram</h1>

<img src="/testing3/public/image/ER.jpg" alt="ER Diagram" style="width:800px;height:350px;">

<br>
<br>
<br>

<h1>Document</h1>
<br>

<p>Click on the PDF icon below to download the PDF file</p>
<a href="/testing3/public/documents/2703ICTAssignment1.pdf" download>
  <img src="/testing3/public/image/pdf.png" alt="PDF FIle" style="width:50px;height:70px;">
</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/testing3/resources/views/documentation.blade.php ENDPATH**/ ?>