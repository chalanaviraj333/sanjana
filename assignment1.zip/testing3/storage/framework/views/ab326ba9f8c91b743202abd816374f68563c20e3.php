
<?php $__env->startSection('title','Users'); ?>
<?php $__env->startSection('body'); ?>
<?php if(isset($values)): ?>
<?php $__currentLoopData = $values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card-body pb-1 mt-3 rounded" style="position: relative">
    <div class="card-title row">
        <a class="text-decoration-none text-dark" href="<?php echo e(url('/posts/'.$item->id)); ?>">
            <div class="col-md-1">
                <img class="icon " src="<?php echo e(isset($item->icon) ? url($item->icon) : url('image/img.jpg')); ?>" alt="icon">
        </a>
    </div>
    <div class="col-md-10 mt-3">
        <a class="text-decoration-none text-dark" href="<?php echo e(url('/posts/'.$item->id)); ?>">
            <h3><?php echo e($item->user_name); ?></h3>
        </a>
    </div>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<h1>No details found...</h1>
<?php endif; ?>
<script>
    // Disable form submissions if there are invalid fields
(function() {
  'use strict';
  window.addEventListener('load', function() {
    // Get the forms we want to add validation styles to
    var forms = document.getElementsByClassName('needs-validation');
    // Loop over them and prevent submission
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();

function readURL(input) {
            if (input.files && input.files[0]) {
               var reader = new FileReader();
               reader.onload = function(e) {
                  $('#preview_icon').attr('src', e.target.result);
               }
               reader.readAsDataURL(input.files[0]);
            }
         }
         $("#icon").change(function() {
            readURL(this);
         });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/testing3/resources/views/users.blade.php ENDPATH**/ ?>