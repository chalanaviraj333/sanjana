<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class userController extends Controller
{
    public function users(Request $request, $id = 0)
    {
        $dataArr = DB::table('users_tbl')->select('users_tbl.*')->get();

        return view('users')->with('values', $dataArr);
    }

    public function posts(Request $request, $id)
    {
        $dataArr = DB::table('post_tbl')->select('post_tbl.*', 'post_tbl.id as post_id', 'users_tbl.*')
            ->join('users_tbl', 'users_tbl.id', '=', 'post_tbl.user_id')
            ->orderBy('post_tbl.id', 'desc')
            ->where('post_tbl.user_id', '=', $id)
            ->get();

        $total = DB::table('comments_tbl')
            ->select(DB::raw('count(post_id) as total,post_id'))
            ->groupBy('post_id')
            ->orderBy('post_id', 'desc')
            ->get();
        return view('recentpost')->with('values', $dataArr)->with('total',$total);
    }
}
