<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class commentController extends Controller
{
    public function comments(Request $request, $id = 0)
    {
        $postArr = DB::table('post_tbl')->select('post_tbl.*', 'post_tbl.id as post_id', 'users_tbl.*')
            ->join('users_tbl', 'users_tbl.id', '=', 'post_tbl.user_id')
            ->where('post_tbl.id', '=', $id)
            ->get();

        $comments = DB::table('comments_tbl')
            ->select('post_tbl.*', 'post_tbl.id as post_id', 'comments_tbl.*', 'users_tbl.user_name')
            ->join('post_tbl', 'post_tbl.id', '=', 'comments_tbl.post_id')
            ->join('users_tbl', 'users_tbl.id', '=', 'comments_tbl.user_id')
            ->where('comments_tbl.post_id', '=', $id)
            ->orderBy('comments_tbl.id', 'desc')
            ->get();

        return view('comments')->with('postArr', $postArr)->with('comments', $comments);
    }

    public function commentadd(Request $request)
    {
        $dataArr['post_id']    = $request->post_id;
        $dataArr['user_id']    = null;
        $dataArr['u_name']     = $request->u_name;
        $dataArr['comment']    = $request->message;
        $dataArr['comment_id'] = $request->comment_id;

        $user = DB::table('users_tbl')->where('user_name', '=', $dataArr['u_name'])->get();
        foreach ($user as $data) {
            $dataArr['user_id'] = $data->id;
        }
        if ($dataArr['user_id'] == Null) {
            DB::table('users_tbl')->insert(['user_name' => $dataArr['u_name']]);
            $dataArr['user_id'] = DB::table('users_tbl')->where('user_name', '=', $dataArr['u_name'])->first()->id;
        }

        if ($dataArr['comment_id'] == null) {
            DB::table('comments_tbl')->insert([
                'post_id'      => $dataArr['post_id'],
                'user_id'      => $dataArr['user_id'],
                'comment'      => $dataArr['comment']
            ]);
            return redirect('comments/' . $dataArr['post_id']);
        } else {
            DB::update('update comments_tbl set comment = ? where id = ?', [$dataArr['comment'], $dataArr['comment_id']]);

            return redirect('comments/' . $dataArr['post_id']);
        }
    }

    public function comedit(Request $request, $id = 0)
    {
        $comArr = DB::table('comments_tbl')
            ->select('comments_tbl.*', 'users_tbl.user_name')
            ->join('users_tbl', 'users_tbl.id', '=', 'comments_tbl.user_id')
            ->where('comments_tbl.id', '=', $id)
            ->get();

        foreach ($comArr as $data) {
            $editArr['id'] = $data->id;
            $editArr['user_id'] = $data->user_id;
            $editArr['post_id'] = $data->post_id;
            $editArr['comment'] = $data->comment;
            $editArr['user_name'] = $data->user_name;
        }
        $postArr = DB::table('post_tbl')->select('post_tbl.*', 'post_tbl.id as post_id', 'users_tbl.*')
            ->join('users_tbl', 'users_tbl.id', '=', 'post_tbl.user_id')
            ->where('post_tbl.id', '=',  $editArr['post_id'])
            ->get();
        
        return view('comments')->with('postArr', $postArr)->with('cmtArr', $editArr);
    }

    public function comentsdelete(Request $request)
    {
        $id = $request->id;
        DB::delete('delete from comments_tbl where id = ?', [$id]);
        return back()->with('success', 'Post deleted successfully');
    }
}
