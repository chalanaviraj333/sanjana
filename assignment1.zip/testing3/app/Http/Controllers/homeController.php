<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\File;
use DB;

class homeController extends Controller
{
    public function home(Request $request, $data = 0)
    {
        if ($data != 0) {
            $postArr = DB::table('post_tbl')->select('post_tbl.*', 'post_tbl.id as post_id', 'users_tbl.*')
                ->join('users_tbl', 'users_tbl.id', '=', 'post_tbl.user_id')
                ->where('post_tbl.id', '=', $data)
                ->get();

            foreach ($postArr as $value) {
                $editArr['post_id'] = $value->post_id;
                $editArr['icon'] = $value->icon;
                $editArr['post_title'] = $value->post_title;
                $editArr['post_details'] = $value->post_details;
                $editArr['user_id'] = $value->user_id;
                $editArr['user_name'] = $value->user_name;
            }
            return view('home')->with('postArr', $editArr);
        } else {

            $dataArr = DB::table('post_tbl')->select('post_tbl.*', 'post_tbl.id as post_id', 'users_tbl.*')
                ->join('users_tbl', 'users_tbl.id', '=', 'post_tbl.user_id')
                ->orderBy('post_tbl.id', 'desc')
                ->get();

            $total = DB::table('comments_tbl')
                ->select(DB::raw('count(post_id) as total,post_id'))
                ->groupBy('post_id')
                ->orderBy('post_id', 'desc')
                ->get();

            return view('home')->with('values', $dataArr)->with('total', $total);
        }
    }

    public function postdelete(Request $request)
    {
        $id = $request->id;
        DB::delete('delete from post_tbl where id = ?', [$id]);

        return redirect('home')->with('success', 'Post deleted successfully');
    }

    public function recentpost()
    {
        $date = Carbon::now()->subDay(7)->toDateString();
        $dataArr = DB::table('post_tbl')->select('post_tbl.*', 'post_tbl.id as post_id', 'users_tbl.*')
            ->join('users_tbl', 'users_tbl.id', '=', 'post_tbl.user_id')
            ->orderBy('post_tbl.id', 'desc')
            ->where('post_tbl.date', '>', $date)
            ->get();

        $total = DB::table('comments_tbl')
            ->select(DB::raw('count(post_id) as total,post_id'))
            ->groupBy('post_id')
            ->orderBy('post_id', 'desc')
            ->get();

        return view('recentpost')->with('values', $dataArr)->with('total', $total);
    }

    public function addpost(Request $request)
    {
        $dataArr['id']      = $request->id;
        $dataArr['title']   = $request->title;
        $dataArr['icon']    = 'image/img.jpg';
        $dataArr['name']    = $request->u_name;
        $dataArr['message'] = $request->message;
        $dataArr['date'] = Carbon::today()->toDateString();
        $dataArr['user_id'] = null;
        $user = DB::table('users_tbl')->where('user_name', '=', $dataArr['name'])->get();
        foreach ($user as $data) {
            $dataArr['user_id'] = $data->id;
        }
        
        if ($dataArr['user_id'] == null) {

            if ($request->hasFile('icon')) {
                $deshtinationPath = 'uploads';
                $image = $request->file('icon');
                $input['imagename'] = time() . '.' . $image->getClientOriginalExtension();
                $image->move($deshtinationPath, $input['imagename']);
                $dbPath = $deshtinationPath . '/' . $input['imagename'];
                $dataArr['icon'] = $dbPath;
            }
            // =============add new post======================
            DB::table('users_tbl')->insert(['user_name' => $dataArr['name'], 'icon' => $dataArr['icon']]);
            $dataArr['user_id'] = DB::table('users_tbl')->where('user_name', '=', $dataArr['name'])->first()->id;
            DB::table('post_tbl')->insert([
                'user_id'      => $dataArr['user_id'],
                'post_title'   => $dataArr['title'],
                'post_details' => $dataArr['message'],
                'date'         => $dataArr['date']
            ]);
            return redirect('home')->with('success', 'Post Added Successfully');
        } else {


            if ($dataArr['id'] != null) {
            // ============= update post======================
                
                DB::update('update post_tbl set post_title = ?,post_details=?,date=? where id = ?', [$dataArr['title'], $dataArr['message'], $dataArr['date'], $dataArr['id']]);
                return redirect('comments/' . $dataArr['id']);
            } else {
                DB::table('post_tbl')->insert([
                    'user_id'      => $dataArr['user_id'],
                    'post_title'   => $dataArr['title'],
                    'post_details' => $dataArr['message'],
                    'date'         => $dataArr['date']
                ]);
                return redirect('home');
            }
        }
    }

}
