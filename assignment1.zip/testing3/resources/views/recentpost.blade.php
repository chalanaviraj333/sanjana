@extends('master.master')
@section('title','Most Recent Posts')
@section('body')
@isset($values)
@foreach ($values as $item)
<div class="card-body rounded my-2" style="position: relative">
    <div class="card-title row">
        <div class="col-md-1">
            <a class="text-decoration-none text-dark" href="{{url('/comments/'.$item->post_id)}}">
                <img class="icon" src="{{ isset($item->icon) ? url($item->icon) : url('image/img.jpg') }}" alt="icon"
                    id="preview_icon">
        </div>
        <div class="col-md-10 mt-2">
            <h3>{{$item->post_title}}</h3>
            <footer class="blockquote-footer">{{$item->user_name}}|&nbsp;<i class="fa fa-calendar"></i>
                {{ $item->date }}
            </footer>
            </a>
        </div>
        <div style="position:absolute;z-index:1;right:10px; ">
            <div class="dropdown dropleft ">
                <button type="button" class="btn" data-toggle="dropdown">
                    <i class="fa fa-ellipsis-v"></i>
                </button>
                <div class="dropdown-menu">
                    <a class="dropdown-item text-dark" href="{{ url('home/'.$item->post_id) }}"><i
                            class="fa fa-pencil-square-o text-secondary"></i>&nbsp;Edit</a>
                    <a class="dropdown-item text-dark modalopen" data-id="{{ $item->post_id }}" href="#modalForm"
                        data-toggle="modal"><i class="fa fa-trash-o text-danger"></i>&nbsp;&nbsp;Delete</a>
                </div>
            </div>
        </div>
    </div>
    <a class="text-decoration-none text-dark" href="{{url('/comments/'.$item->post_id)}}">
        <div class="card-body" style="background-color: #f7f7f7;">
            {{ $item->post_details }}
            <div class="float-right">
                @foreach($total as $data)
                @if($item->post_id ==$data->post_id )
                <footer class="blockquote-footer" style="font-size: 1.5rem">
                    {{$data->total}}&nbsp;<i class="fa fa-comments-o"></i>
                </footer>
                @endif
                @endforeach
            </div>
        </div>
    </a>
</div>
<div class="modal fade" id="modalForm">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="post" action="{{ url('/postdelete') }}">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Post Delete</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <input type="hidden" name="id" class="id">
                <div class="modal-body">Select "Delete" below if you are ready to want to delete this Post <span
                        class="text-capitalize font-weight-bold" id="name"></span>.</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"
                        onclick="reset();">Close</button>
                    <button type="submit" class="btn btn-danger">
                        {{ __('Delete') }}
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endforeach
@else
<h1>No details found...</h1>
@endisset
@endsection