@extends('master.master')
@section('title','Documentation')
@section('body')

<br>
<br>
<br>
<h1>ER Diagram</h1>

<img src="/testing3/public/image/ER.jpg" alt="ER Diagram" style="width:800px;height:350px;">

<br>
<br>
<br>

<h1>Document</h1>
<br>

<p>Click on the PDF icon below to download the PDF file</p>
<a href="/testing3/public/documents/2703ICTAssignment1.pdf" download>
  <img src="/testing3/public/image/pdf.png" alt="PDF FIle" style="width:50px;height:70px;">
</a>

@endsection