@extends('master.master')
@section('title','Home')
@section('body')
{{-- {{ dump($values) }} --}}
<div class="card-body rounded my-2" style="background-color: #f7f7f7">
   <form method="POST" action="{{url('/post')}}" class="needs-validation" novalidate enctype="multipart/form-data">
      <div class="card-title row mb-0">
         <div class="col-md-1 mb-0">
            @csrf
            <img class="mt-1" src="{{isset($postArr['icon']) ? url($postArr['icon']) : url('image/img.jpg') }}"
               alt="icon" id="preview_icon" onclick="event.preventDefault();document.getElementById('icon').click();"
               style="width: 70px;height: 70px;border-radius: 50%;">
            <input class="form-control" type="file" name="icon" accept="image/*" id="icon" style="display: none;">
         </div>
         <div class="col-md mt-1">
            <input class="form-control" placeholder="Title" type="text" name="title"
               value="{{isset($postArr['post_title']) ? $postArr['post_title'] : old('title') }}" required>

            <input type="hidden" name="id" value="{{isset($postArr['post_id']) ? $postArr['post_id'] : old('id') }}">
         </div>
         <div class="col-md mt-1">
            @if(isset($postArr))
            <input class="form-control" placeholder="User Name" type="text" name="u_name"
               value="{{ $postArr['user_name'] }}" readonly required>
            @else
            <input class="form-control" placeholder="User Name" type="text" name="u_name"
               value="{{isset($postArr['user_name']) ? $postArr['user_name'] : old('u_name') }}" required>
            @endif
         </div>
      </div>
      <div class="row mt-0">
         <div class="col-md-1"></div>
         <div class="col-md-11 mt-1">
            <div>
               <textarea class="form-control" name="message" placeholder="Message"
                  required>{{isset($postArr['post_details']) ? $postArr['post_details'] : old('message') }}</textarea>
            </div>
            <br>
            <div class="row">
               <div class="col-md-4 mt-1">
                  <button class="btn btn-secondary text-white px-5 nbtn" type="submit">Post</button>
               </div>
            </div>
         </div>
      </div>
   </form>
</div>
@if(isset($values))
@foreach ($values as $item)
<div class="card-body rounded my-2" style="position: relative">
   <div class="card-title row">
      <div class="col-md-1">
         <a class="text-decoration-none text-dark" href="{{url('/comments/'.$item->post_id)}}">
            <img class="icon" src="{{ isset($item->icon) ? url($item->icon) : url('image/img.jpg') }}" alt="icon"
               id="preview_icon">
      </div>
      <div class="col-md-10 mt-2">
         <h3>{{$item->post_title}}</h3>
         <footer class="blockquote-footer">{{$item->user_name}}|&nbsp;<i class="fa fa-calendar"></i> {{ $item->date }}
         </footer>
         </a>
      </div>
      <div style="position:absolute;z-index:1;right:10px; ">
         <div class="dropdown dropleft ">
            <button type="button" class="btn" data-toggle="dropdown">
               <i class="fa fa-ellipsis-v"></i>
            </button>
            <div class="dropdown-menu">
               <a class="dropdown-item text-dark" href="{{ url('home/'.$item->post_id) }}"><i
                     class="fa fa-pencil-square-o text-secondary"></i>&nbsp;Edit</a>
               <a class="dropdown-item text-dark modalopen" data-id="{{ $item->post_id }}" href="#modalForm"
                  data-toggle="modal"><i class="fa fa-trash-o text-danger"></i>&nbsp;&nbsp;Delete</a>
            </div>
         </div>
      </div>
   </div>
   <a class="text-decoration-none text-dark" href="{{url('/comments/'.$item->post_id)}}">
      <div class="card-body" style="background-color: #f7f7f7;">
         {{ $item->post_details }}
         <div class="float-right">
            @foreach($total as $data)
            @if($item->post_id ==$data->post_id )
            <footer class="blockquote-footer" style="font-size: 1.5rem">
               {{$data->total}}&nbsp;<i class="fa fa-comments-o"></i>
            </footer>
            @endif
            @endforeach
            </footer>
         </div>
      </div>
   </a>
</div>
<div class="modal fade" id="modalForm">
   <div class="modal-dialog modal-lg">
      <div class="modal-content">
         <form method="post" action="{{ url('/postdelete') }}">
            @csrf
            <div class="modal-header">
               <h5 class="modal-title">Post Delete</h5>
               <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
               </button>
            </div>
            <input type="hidden" name="id" class="id">
            <div class="modal-body">Select "Delete" below if you are ready to want to delete this Post <span
                  class="text-capitalize font-weight-bold" id="name"></span>.</div>
            <div class="modal-footer">
               <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="reset();">Close</button>
               <button type="submit" class="btn btn-danger">
                  {{ __('Delete') }}
               </button>
            </div>
         </form>
      </div>
   </div>
</div>
@endforeach
@endif
<script src="https://code.jquery.com/jquery-3.1.1.slim.min.js"></script>
<script type="text/javascript">
   $('.modalopen').click(function() {
    
         $('.id').attr('value',$(this).data('id'));
    
    });
   // Disable form submissions if there are invalid fields
         (function() {
            'use strict';
            window.addEventListener('load', function() {
               // Get the forms we want to add validation styles to
               var forms = document.getElementsByClassName('needs-validation');
               // Loop over them and prevent submission
               var validation = Array.prototype.filter.call(forms, function(form) {
                  form.addEventListener('submit', function(event) {
                     if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                     }
                     form.classList.add('was-validated');
                  }, false);
               });
            }, false);
         })();
         
         function readURL(input) {
            if (input.files && input.files[0]) {
               var reader = new FileReader();
               reader.onload = function(e) {
                  $('#preview_icon').attr('src', e.target.result);
               }
               reader.readAsDataURL(input.files[0]);
            }
         }
         $("#icon").change(function() {
            readURL(this);
         });

</script>

@endsection