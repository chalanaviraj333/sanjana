@extends('master.master')
@section('title','Comments')
@section('body')
{{-- {{ dump($postArr) }} --}}

{{----------- Post Details ------------}}

@foreach($postArr as $item)
<div class="card-body rounded my-2" style="position: relative">
    <div class="card-title row">
        <div class="col-md-1">
            <a class="text-decoration-none text-dark" href="{{url('/comments/'.$item->post_id)}}">
                <img class="icon" src="{{ isset($item->icon) ? url($item->icon) : url('image/img.jpg') }}" alt="icon"
                    id="preview_icon" style="width: 70px;height: 70px;border-radius: 50%;">
        </div>
        <div class="col-md-10 mt-2">
            <h3>{{$item->post_title}}</h3>
            <footer class="blockquote-footer">{{$item->user_name}}&nbsp;|&nbsp;<i class="fa fa-calendar"></i>
                {{ $item->date }}
            </footer>
            </a>
        </div>
    </div>
    <div class="card-body" style="background-color: #f7f7f7;">
        {{ $item->post_details }}
        <div class="float-right">
            {{-- <footer class="blockquote-footer" style="font-size: 1.5rem">20&nbsp;<i class="fa fa-comments-o"></i>
            </footer> --}}
        </div>
    </div>
</div>

{{---------comment add ---------}}
<div class="card-body rounded">
    <form method="POST" action="{{url('/commentadd')}}" class="needs-validation" novalidate>
        <div class="card-title row mb-0">
            @csrf
            <div class="col-md mt-1">
                <input type="hidden" name="post_id" value="{{$item->post_id}}">
                <input type="hidden" name="user_id" value="{{$item->user_id}}">
                <input type="hidden" name="comment_id" value="{{isset($cmtArr['id']) ? $cmtArr['id'] : null}}">
                @if(isset($cmtArr))
                <input class="form-control" placeholder="User Name" type="text" name="u_name"
                    value="{{isset($cmtArr['user_name']) ? $cmtArr['user_name'] : null}}" readonly required>
                @else
                <input class="form-control" placeholder="User Name" type="text" name="u_name" required>
                @endif
            </div>
        </div>
        <div class="row mt-1">
            <div class="col-md mt-1">
                <textarea class="form-control" name="message" placeholder="Comment"
                    required>{{isset($cmtArr['comment']) ? $cmtArr['comment'] : old('comment')}}</textarea>
                <button class="mt-2 btn btn-secondary text-white px-5 nbtn" type="submit">Post</button>
            </div>
        </div>
    </form>
</div>
@endforeach
{{-------------------comments--------------------}}
{{--- {{ dump($comments) }} ---}}
@if(isset($comments))
@foreach($comments as $data)
<div class="card-body my-2 rounded">
    <div class="card-title row">
        <div class="col-md">
            <div class="dropdown dropleft float-right">
                <button type="button" class="btn" data-toggle="dropdown">
                    <i class="fa fa-ellipsis-v"></i>
                </button>
                <div class="dropdown-menu">
                    <a class="dropdown-item text-dark" href="{{url('/comedit/'.$data->id)}}"><i
                            class="fa fa-pencil-square-o text-secondary"></i>&nbsp;Edit</a>
                    <a class="dropdown-item text-dark modalopen" data-id="{{ $data->id }}" href="#modalForm"
                        data-toggle="modal"><i class="fa fa-trash-o text-danger"></i>&nbsp;&nbsp;Delete</a>
                </div>
            </div>
            <div class="mt-2">
                {{ $data->comment }}
                <div class="float-right mr-2">
                    <footer class="blockquote-footer">{{ $data->user_name }}
                    </footer>
                </div>
            </div>
        </div>
    </div>
</div>
@endforeach
@endif
<div class="modal fade" id="modalForm">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="post" action="{{ url('/comentsdelete') }}">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Comment Delete</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <input type="hidden" name="id" class="id">
                <div class="modal-body">Select "Delete" below if you are ready to want to delete this Comment <span
                        class="text-capitalize font-weight-bold" id="name"></span>.</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"
                        onclick="reset();">Close</button>
                    <button type="submit" class="btn btn-danger">
                        {{ __('Delete') }}
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    $('.modalopen').click(function() {
         $('.id').attr('value',$(this).data('id'));
    });
    // Disable form submissions if there are invalid fields
(function() {
  'use strict';
  window.addEventListener('load', function() {
    // Get the forms we want to add validation styles to
    var forms = document.getElementsByClassName('needs-validation');
    // Loop over them and prevent submission
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();
</script>
@endsection