<?php
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/','homeController@home');
Route::get('/home/{data?}','homeController@home');
Route::get('/recentpost','homeController@recentpost');
Route::get('postget/{id?}', 'homeController@postget');
Route::post('/post', 'homeController@addpost');
Route::post('/postdelete', 'homeController@postdelete');
Route::get('/comments/{id}', 'commentController@comments');
Route::get('/comedit/{id}', 'commentController@comedit');
Route::post('/commentadd', 'commentController@commentadd');
Route::post('/comentsdelete', 'commentController@comentsdelete');
Route::get('/users', 'userController@users');
Route::get('/posts/{id?}', 'userController@posts');

Route::get('/documentation', function(){
    return view ('documentation');
});

