drop table if exists post;
drop table if exists comment;
create table post (    
    id integer not null primary key autoincrement,    
    title varchar(20) not null,
    body text default '',
    postDate date not null,
    userName text not null

);
create table comment (    
    id integer not null primary key autoincrement,     
    body text default '',
    postDate date not null,
    userName text not null,
    postId integer not null,
    FOREIGN KEY (postId) REFERENCES post(id)

);  
insert into post values (null, "Post 1", "This is just a test post", datetime('now'),"TestUser1");
insert into post values (null, "Post 2", "This is second  test post", datetime('now'),"TestUser1");
insert into post values (null, "Post 3", "This is third  test post", datetime('now'),"TestUser2");

insert into comment values(null, "FirstComment" , datetime('now'), "TestUser1", 2);
insert into comment values(null, "SecondComment" , datetime('now'), "TestUser1", 1);
insert into comment values(null, "ThirdComment" , datetime('now'), "TestUser2", 2);