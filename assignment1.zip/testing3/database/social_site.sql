drop table if exists comments_tbl;
drop table if exists post_tbl;
drop table if exists users_tbl;

create table comments_tbl (
  id integer not null primary key autoincrement,
  user_id integer(10) not null,
  post_id integer(10) not null,
  comment text not null
);


create table post_tbl (
  id integer not null primary key autoincrement,
  user_id integer(10) not null,
  post_title varchar(255) not null,
  post_details text not null,
  date date not null
);

create table users_tbl (
  id integer not null primary key autoincrement,
  user_name varchar(255) not null,
  icon varchar(255) default null
);




insert into comments_tbl values (19, 15, 19, "thanks");
insert into comments_tbl values (20, 12, 19, "happy birthday miyuru");


insert into post_tbl values (19, 13, "chalana viraj", "Happy birthday mehani", "2019-08-31");
insert into post_tbl values (20, 14, "Malith Lakshan", "Done and dusted for the day", "2019-08-31");


insert into users_tbl values (12, "Imesha", 'image/img.jpg');
insert into users_tbl values (13, "Chalana", 'image/img.jpg');
insert into users_tbl values (14, "Malith", 'uploads/1567264199.png');
insert into users_tbl values (15, "Sankit", 'uploads/1567264199.png');
